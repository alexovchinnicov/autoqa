## Allure HAR Viewer Plugin

Plugin provides "Inspect requests" block to the Allure report via [HAR Viewer Extension API](https://github.com/janodvarko/harviewer/wiki/API).

### Configuration

* Attach files with .har extension to testcase
* Generate allure report

### Inspect your requests

![Allure HARViewer](http://imgur.com/download/OKd6IpW)
